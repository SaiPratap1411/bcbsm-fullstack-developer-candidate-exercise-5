package com.example.demo.controller;

import com.example.demo.model.Email;
import com.example.demo.model.Login;
import com.example.demo.service.EmailService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.List;
import java.util.Optional;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private JavaMailSender javaMailSender;



    @PostMapping("/save")
    public ResponseEntity<Email> saveOrUpdate(@RequestBody Email email) {
        Email savedUserEmail = emailService.save(email);
        return new ResponseEntity<Email>(savedUserEmail, HttpStatus.CREATED);

    }

    @PostMapping(path = "/send", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public ResponseEntity<String> sendEmail(
            @RequestParam String from,
            @RequestParam String to,
            @RequestParam("attachment") MultipartFile file,
            @RequestParam String subject,
            @RequestParam String body
    ) {
        try {
            System.out.println(file.getContentType());


            MimeMessage mimeMessage=javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper=new MimeMessageHelper(mimeMessage,true);
            mimeMessageHelper.setFrom("sai.pratap1411@gmail.com");
            mimeMessageHelper.setTo(to);
            mimeMessageHelper.setText(body);
            mimeMessageHelper.setSubject(subject);
            String mimeType = URLConnection.guessContentTypeFromName(file.getOriginalFilename());
            mimeMessageHelper.addAttachment(file.getOriginalFilename(), new InputStreamSource() {
                @Override
                public InputStream getInputStream() throws IOException {
                    return file.getInputStream();
                }
            }, mimeType);

            javaMailSender.send(mimeMessage);

            emailService.storeEmailWithAttachment(from, to, file, subject, body);
            return ResponseEntity.ok("Email sent successfully");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to store email");
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Email>> getAllEmails(@RequestParam String email) {
        try {
            List<Email> emails = emailService.getAllEmails(email);
            return new ResponseEntity<>(emails, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<Login> login (@RequestBody Login email) {
        Optional<Login> user2 = emailService.findByUsername(email.getUsername());
        if(user2.isPresent()){
            if (user2.get().getUsername().equals(email.getUsername()) && user2.get().getPassword().equals(email.getPassword())) {
                return new ResponseEntity<Login>(email, HttpStatus.OK);
            }
        }
        return new ResponseEntity<Login>(email, HttpStatus.NOT_FOUND);
    }

}