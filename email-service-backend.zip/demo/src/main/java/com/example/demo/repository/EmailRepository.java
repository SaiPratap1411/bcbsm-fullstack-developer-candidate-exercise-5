package com.example.demo.repository;

import com.example.demo.model.Email;
import com.example.demo.model.Login;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface EmailRepository  extends MongoRepository<Email, String> {

    Optional<Login> findByUsername(String username);
    List<Email> findByUploadUser(String user);
}
