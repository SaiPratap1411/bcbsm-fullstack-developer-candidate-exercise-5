package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document (collection = "emails")
public class Email {


        @Id
        private String id;

        private String username;

         private String password;
        private String fromEmailID;

        private String subject;

        private String body;
        private String recipientEmailID;
        private String attachmentFileName;
        private byte[] attachmentFileData;
        private String uploadUser;

    private String uploadDate;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFromEmailID() {
        return fromEmailID;
    }

    public void setFromEmailID(String fromEmailID) {
        this.fromEmailID = fromEmailID;
    }

    public String getRecipientEmailID() {
        return recipientEmailID;
    }

    public void setRecipientEmailID(String recipientEmailID) {
        this.recipientEmailID = recipientEmailID;
    }

    public String getAttachmentFileName() {
        return attachmentFileName;
    }

    public void setAttachmentFileName(String attachmentFileName) {
        this.attachmentFileName = attachmentFileName;
    }

    public byte[] getAttachmentFileData() {
        return attachmentFileData;
    }

    public void setAttachmentFileData(byte[] attachmentFileData) {
        this.attachmentFileData = attachmentFileData;
    }

    public String getUploadUser() {
        return uploadUser;
    }

    public void setUploadUser(String uploadUser) {
        this.uploadUser = uploadUser;
    }

    public String getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(String uploadDate) {
        this.uploadDate = uploadDate;
    }

}
