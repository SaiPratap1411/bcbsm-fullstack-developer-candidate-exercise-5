package com.example.demo.service;

import com.example.demo.model.Email;
import com.example.demo.model.Login;
import com.example.demo.repository.EmailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
public class EmailService  {


    @Autowired
    private EmailRepository emailRepository;

    public Optional<Login> findByUsername(String username) {
        return emailRepository.findByUsername(username);
    }

    public Email save(Email email) {
        return emailRepository.save(email);
    }

    public void storeEmailWithAttachment(String from, String to, MultipartFile file, String subject, String body) throws  IOException {
        Email email = new Email();
        email.setFromEmailID(from);
        email.setRecipientEmailID(to);
        email.setSubject(subject);
        email.setBody(body);
        email.setUploadUser(from);
        email.setAttachmentFileName(file.getOriginalFilename());
        email.setAttachmentFileData(file.getBytes());
        LocalDateTime instance = LocalDateTime.now();
        DateTimeFormatter formatter
                = DateTimeFormatter.ofPattern("MM-dd-yyyy hh:mm");
        String formattedString = formatter.format(instance);
        email.setUploadDate(formattedString);
        emailRepository.save(email);
    }
    public List<Email> getAllEmails(String email) {
        return emailRepository.findByUploadUser(email);
    }
}
