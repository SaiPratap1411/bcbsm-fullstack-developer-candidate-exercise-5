import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.css']
})
export class EmailComponent {
  emailForm: any = this.fb.group({
    from: [localStorage.getItem('username'), Validators.required],
    to: ['', Validators.required],
    subject: ['', Validators.required],
    body: ['', Validators.required],
    attachment: ['', Validators.required]
  });
  file: any;

  constructor(private fb: FormBuilder, private router: Router, private userService: UserService) {
    if (!localStorage.getItem("username")) {
      this.router.navigateByUrl("/login");
    }
  }

  navigateToItems() {
    this.router.navigateByUrl("/items");
  }

  uploadFile(event: any) {
    this.file = event.target.files[0];
  }

  sendEmail() {
    this.emailForm.markAllAsTouched();
    if (this.emailForm.valid) {
      const emailData = this.emailForm.value;
      
      let formData = new FormData();
      for (let key in emailData) {
        formData.append(key, emailData[key]);
      }
      formData.set("attachment", this.file);
      
      this.userService.sendEmail(formData).subscribe(
        (data: any) => { alert(data); this.router.navigateByUrl("/items"); },
        (err) => { console.error(err); }
      )
    }
  }

  logout() {
    localStorage.removeItem("username");
    this.router.navigateByUrl("/login");
  }
}
