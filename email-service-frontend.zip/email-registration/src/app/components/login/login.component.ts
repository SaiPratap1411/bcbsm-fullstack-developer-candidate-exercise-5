import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserLogin } from 'src/app/models/user.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userLoginForm: any = this.fb.group({
    username: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9]*$')]],
    password: ['', Validators.required]
  });

  constructor(private fb: FormBuilder, private userService: UserService, private router: Router) { }

  login() {
    this.userLoginForm.markAllAsTouched();
    if (this.userLoginForm.valid) {
      const user: UserLogin = this.userLoginForm.value as UserLogin;
      this.userService.login(user).subscribe(
        (data: any) => { localStorage.setItem("username", data.username); this.router.navigateByUrl("/email") },
        (err) => { console.error(err); }
      )
    }
  }
}
