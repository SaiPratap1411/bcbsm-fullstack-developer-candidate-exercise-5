import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements AfterViewInit, OnDestroy, OnInit {
  username: string | null;
  @ViewChild(DataTableDirective, { static: false })
  dtElement?: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: any = new Subject();

  constructor(private router: Router, private userService: UserService, private http: HttpClient, private elementRef: ElementRef) {
    this.username = localStorage.getItem("username");
    if (!this.username) {
      this.router.navigateByUrl("/login");
    }
  }


  ngOnInit(): void {
    this.dtOptions = {
      pagingType: 'full_numbers',
      searching: true,
      ordering: true,
      ajax: (dataTablesParameters: any, callback) => {
        this.http
          .get(
            'http://localhost:8080/all?email=' + this.username,
          ).subscribe((resp: any) => {
            callback({
              recordsTotal: 10,
              recordsFiltered: 10,
              data: resp
            });
          });
      },
      columns: [{
        title: 'To Email ID',
        data: 'recipientEmailID'
      }, {
        title: 'Attachment File Name',
        data: 'attachmentFileName'
      }, {
        title: 'Attachment File',
        data: 'attachmentFileData',
        render: (data, type, row) => {
          return `<button class="btn btn-sm btn-success id-link" data-attachment-file-name="${row.attachmentFileName}" data-attachment-file-data="${row.attachmentFileData}">Download</button>`;
        }
      }],
      language: {
        emptyTable: "No data available in table",
        zeroRecords: "No data available in table",
        infoEmpty: "No entries to show"
      },
      drawCallback: (data: any) => {
        const self = this;
        self.bindClickToViewDetails();
      }
    };
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
    this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.columns().every(function () {
        const that = this;
        $('input', this.footer()).on('keyup change', function () {
          let el: any = this;
          if (that.search() !== el['value']) {
            that
              .search(el['value'])
              .draw();
          }
        });
      });
    });
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  navigateToEmail() {
    this.router.navigateByUrl("/email");
  }

  logout() {
    localStorage.removeItem("username");
    this.router.navigateByUrl("/login");
  }

  bindClickToViewDetails(): void {
    const el: any = this.elementRef.nativeElement;
    el.querySelectorAll('button.id-link').forEach(function (item: any) {

      item.addEventListener('click', function ($event: any) {
        const fileData = $($event.currentTarget).data('attachmentFileData');
        const fileName = $($event.currentTarget).data('attachmentFileName');

        const byteString = atob(fileData);
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
          ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab]);
        const url = URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = fileName;
        link.click();

        URL.revokeObjectURL(url)
      });
    });
  }
}
