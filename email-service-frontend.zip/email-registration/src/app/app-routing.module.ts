import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { EmailComponent } from './components/email/email.component';
import { ItemsComponent } from './components/items/items.component';

const routes: Routes = [
  {path: "login", component: LoginComponent},
  {path: "email", component: EmailComponent},
  {path: "items", component: ItemsComponent},
  {path: "", redirectTo: "/login", pathMatch: "full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
