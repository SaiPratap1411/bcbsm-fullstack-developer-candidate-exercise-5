export interface UserLogin {
    username: string;
    password: string;
  }